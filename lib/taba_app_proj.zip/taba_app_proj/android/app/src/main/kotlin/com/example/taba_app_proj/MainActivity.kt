package com.example.taba_app_proj

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
