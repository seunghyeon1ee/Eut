import 'package:flutter/material.dart';
import 'package:taba_app_proj/chatbot/chat_test.dart';
import 'package:taba_app_proj/screen/home_screen.dart';
import 'package:taba_app_proj/screen/register_elder_fin.dart';
import 'package:taba_app_proj/screen/register_fam_1.dart';
// import 'package:taba_app_proj/chatbot/chat1.dart';
import 'package:taba_app_proj/screen/home_screen.dart';


void main() {
  runApp(
    MaterialApp(
        home: ChatTest(),
    ),
  );
}



