import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
// import 'package:provider/provider.dart';
// import 'package:taba_app_proj/chatbot/greeting.dart';
// import 'package:avatar_glow/avatar_glow.dart';
import 'package:simple_ripple_animation/simple_ripple_animation.dart';
import 'package:siri_wave/siri_wave.dart';

class ChatTest extends StatelessWidget {
  const ChatTest({super.key});

  @override
  Widget build(BuildContext context) {
    final siricontroller = IOS7SiriWaveformController(
      amplitude: 0.8,
      color: Colors.redAccent,
      frequency: 10,
      speed: 0.25,
    );
    return SafeArea(
      child: Scaffold(
        body: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 110),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('안녕하세요',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.black, fontSize: 30,
                        fontFamily: 'Noto Sans', fontWeight: FontWeight.w600, height: 0.06),
                  ),
                ],
              ),
              SizedBox(height: 100),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  RippleAnimation(
                    repeat: true,
                    color: Color(0xFFFF7672),
                    minRadius: 90,
                    ripplesCount: 6,
                    child: ClipOval(
                      child: Image.asset('assets/botboy.png',
                          width: 350, height: 350, fit: BoxFit.cover),
                    ),
                    // duration: const Duration(milliseconds: 6 * 300),
                    // delay: const Duration(milliseconds: 300),
                  ),
                ],
              ),

              // AvatarGlow(
              //   startDelay: const Duration(milliseconds: 1000),
              //   glowColor: Color(0xFFFF7672),
              //   glowShape: BoxShape.circle,
              //   curve: Curves.fastOutSlowIn,
              //   child: const Material(
              //     elevation: 0.0, // 그림자
              //     shape: CircleBorder(),
              //     color: Colors.transparent,
              //     child: CircleAvatar(
              //       backgroundColor: Colors.transparent,
              //       // child: SvgPicture.asset('assets/botboy.svg', height: 60),
              //       backgroundImage: AssetImage('assets/botboy_png.png'),
              //       radius: 100.0,
              //     ),
              //   ),
              // ),
              SizedBox(height: 50),
            SiriWaveform.ios7(
              controller: siricontroller,
            options: IOS7SiriWaveformOptions(
            height: 100,
        width: 400,
      ),
        ),

              // SizedBox(height: 70),
              // SvgPicture.asset('assets/record_icon.svg'),

          ],
                ),
              ),
                                    ),
              );
  }
}

